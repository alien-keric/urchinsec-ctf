# sesame

Just a simple secure app to help me access my files easily from the server.